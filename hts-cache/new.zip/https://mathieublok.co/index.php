<html lang="En">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Mathieu Blok, French UX UI Designer & Front-Developer">
<meta name="keywords" content="Portfolio,Webdesign,Graphiste,DA,Developer,Paris,France,HTML,CSS,JS,Mathieu,Mathieu Blok,Blok,Hétic">
<meta name="Mathieu Blok" content="Matt Blok Book">
<link href="css/style.css" rel="stylesheet">
<link href="css/reset.css" rel="stylesheet">
<link rel="icon" href="assets/img/favicon.ico" />
<!-- Library CSS -->
<link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
<!-- Library CSS -->
<title>Blok Book</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function() {
$('.js-scrollTo').on('click', function() { // Au clic sur un élément
var page = $(this).attr('href'); // Page cible
var speed = 750; // Durée de l'animation (en ms)
$('html, body').animate( { scrollTop: $(page).offset().top }, speed ); // Go
return false;
});
});
</script>
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script src="js/script.js" async></script>
<script>
$(window).scroll(function() {
var scroll = $(window).scrollTop();

if (scroll >= 120) {
$("nav").addClass("NavFixedBackground");
} else {
$("nav").removeClass("NavFixedBackground");
}
});
</script>
</head>



<body id="Top" class="Wrapper fadeIn animated BackgroundMobile">
	<div class="WrapperMargin">
		<header>
			<nav>
	<div class="NavFixedWrapper">
		<div class="HeaderNavLeft">
			<p class="Name">Matt Blok <span>👨🏼‍💼</span></p>
		</div>
		<div class="HeaderNavRight">
			<ul>
				<li><a class="js-scrollTo" href=#Projects>Work</a></li>
				<li><a class="js-scrollTo" href=#About>About</a></li>
				<li><a class="js-scrollTo" href=#Contact>Contact</a></li>
			</ul>
		</div>
	</div>
</nav>			<div class="Intro">
				<img src="assets/img/header/circle.png" alt="Background">
				<h1>Hey! I’m Matt, a Paris-Based UX UI Designer & Front-End Developer.</h1>
			</div>
		</header>

		<section class="ProjectsWrapper">
			<div class="ProjectsInfos">
				<div>
					<h2 id="Projects">Selected Work</h2>
				</div>
				<div class="ProjectInfosDescription">
					<p>Find below somes valuable projects<br> I had the chance to work on!</p>
				</div>
			</div>

			<div class='ProjectsListing'>

				<div class="ProjectTemplate BgGeodia">
					<a class="FullCaseLink" href="project-geodia.php"></a>
					<div class="ProjectTemplateImgDesc">
						<div data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="50" class="ProjectInfosWrapper">
							<div class="ProjectTypeWrapper">
								<p class="ProjectType">UI Design</p>
							</div>
							<h3 class="ProjectName">Géodia Conseils</h3>
						</div>
					</div>
				</div>

				<div class="ProjectTemplate BgXaalys">
					<a class="FullCaseLink" href="project-xaalys.php"></a>
					<div class="ProjectTemplateImgDesc">
						<div data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="50" class="ProjectInfosWrapper">
							<div class="ProjectTypeWrapper">
								<p class="ProjectType">UI Design</p>
							</div>
							<h3 class="ProjectName">Xaalys</h3>
						</div>
					</div>
				</div>
			</div>

			<div class='ProjectsListing'>
				<div class="ProjectTemplate BgNutergia">
					<a class="FullCaseLink" href="project-nutergia.php"></a>
					<div class="ProjectTemplateImgDesc">
						<div data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="50" class="ProjectInfosWrapper">
							<div class="ProjectTypeWrapper">
								<p class="ProjectType NutergiaTag">UI Design</p>
							</div>
							<h3 class="ProjectName NutergiaColor">Nutergia®</h3>
						</div>
					</div>
				</div>
				<div class="ProjectTemplate BgSodexo">
					<a class="FullCaseLink" href="project-sodexo.php"></a>
					<div class="ProjectTemplateImgDesc">
						<div data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="50" class="ProjectInfosWrapper">
							<div class="ProjectTypeWrapper">
								<p class="ProjectType">UI Design</p>
							</div>
							<h3 class="ProjectName">Sodexo Ventures</h3>
						</div>
					</div>
				</div>
			</div>

			<div class='ProjectsListing'>
				<div class="ProjectTemplate BgPhotosBook">
					<a class="FullCaseLink" href="project-photographer.php"></a>
					<div class="ProjectTemplateImgDesc">
						<div data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="250" class="ProjectInfosWrapper">
							<div class="ProjectTypeWrapper">
								<p class="ProjectType BlackTag">UI Design</p>
								<p class="ProjectType BlackTag">Freelance</p>
							</div>
							<h3 class="ProjectName BlackColor">Photos Book</h3>
						</div>
					</div>
				</div>
				<div class="ProjectTemplate BgSkillCorner">
					<a class="FullCaseLink" href="project-skillcorner.php"></a>
					<div class="ProjectTemplateImgDesc">
						<div data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="250" class="ProjectInfosWrapper">
							<div class="ProjectTypeWrapper">
								<p class="ProjectType">Front-End Development</p>
							</div>
							<h3 class="ProjectName">SkillC</h3>
						</div>
					</div>
				</div>
			</div>

			<div class='ProjectsListing'>
			<div class="ProjectTemplate BgSamuSocial">
<!-- 				<a class="FullCaseLink" href="project-ssdp.php"></a> -->
					<div class="ProjectTemplateImgDesc">
						<div data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="250" class="ProjectInfosWrapper">
							<div class="ProjectTypeWrapper">
								<p class="ProjectType">Work in progress</p>
								<p class="ProjectType">🔐</p>
							</div>
							<h3 class="ProjectName">Samu Social</h3>
						</div>
					</div>
				</div>
				<div class="ProjectTemplate NewProject">
					<div data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="100" class="NewProjectWrapper">
						<a class="NewProjectLink" href="mailto:matblok@orange.fr">
							<span>💭</span> Start a project
						</a>
					</div>
				</div>
			</div>
		</section>

		<span id="About" class="Anchor">&nbsp;</span>

		<section class="AboutMe">
			<div class="AboutMeContent2Row" data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="100">
				<h4>About me</h4> <img src="assets/img/aboutme/me.svg" alt="Picto">
			</div>
			<p data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="100">In 2017, I had the opportunity to study at Les Gobelins, where I acquired the fundamentals skills in order to work in the graphic industry. Currently, on my final year of a Web Bachelor at Hétic, <span class="MainColorP">I’m now working at the heart of the digital </span>field as UI Designer and Front-Developer.</p>
		</section>

		<section class="AboutUs">
			<div class="AboutUsWrapper">
				<div class="AboutUsContent">
					<div class="AboutUsContent2Row">
						<div>
							<div class="AboutUsTitle2Row" data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="100">
								<h4>About us</h4> 
								<img class="PictoFullTeamDesktop" src="assets/img/aboutus/circle-fullteam.svg" alt="Picto">
								<img class="PictoFullTeamMobile" src="assets/img/aboutus/circle-fullteam-mobile.svg" alt="Picto">
							</div>
							<div data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="100">
								<p class="AboutUsContentDescription" >
									Three complementary minds <span class="BlackColor">ready to craft meaningful digital experiences</span> for you. 
									<br class="BrAboutUsMobile">
									From project management to experience & product design.
								</p>
							</div>
						</div>
						<div class="AboutUsContentCircles">
							<div>
								<img data-aos="fade-left" data-aos-easing="ease-out" data-aos-duration="1000" data-aos-delay="1000"
								src="assets/img/aboutus/circle-1.svg" alt="ManagementCircle">

								<img data-aos="fade-left" data-aos-easing="ease-out" data-aos-duration="500" data-aos-delay="1000"
								src="assets/img/aboutus/circle-2.svg" alt="UXCircle">

								<img data-aos="fade-left" data-aos-easing="ease-out" data-aos-duration="400" data-aos-delay="1000"
								src="assets/img/aboutus/circle-3.svg" alt="UICircle">
							</div>
						</div>
					</div>
					<div class="AboutUsContentProfil">
						<div class="ProfilsWrapper">
							<div data-aos="fade-up" data-aos-duration="1000" data-aos-easing="ease-out" data-aos-delay="100" class="Profil">
								<p>UX-Oriented Digital Producer</p>
								<span>José Teixeira</span>
								<a class="TagLinkAboutUs JoeColorTag" href="https://joetxa.co/" target="_blank">
									Discover
								</a>
								<img class="CircleProfil" src="assets/img/aboutus/circle-gestion.svg" alt="Circle">
							</div>
							<div data-aos="fade-up" data-aos-duration="1000" data-aos-easing="ease-out" data-aos-delay="300" class="Profil ProfilJoe">
								<p>UX UI Designer / Photographer</p>
								<span>Jean-Yves Dogo</span>
								<a class="TagLinkAboutUs JayColorTag" href="https://Jaydogo.co" target="_blank">
									Discover
								</a>
								<img class="CircleProfil" src="assets/img/aboutus/circle-ux.svg" alt="Circle">
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<footer>
			<div class="FooterColumnWrapper">
				<div class="FooterColumn2x">
					<div data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="100" class="ColumnTitle">
						<p>Studies</p>
						<div class="FooterMobileWrapper">
							<div class="ColumnInfos MarginBottom">
								<p class="ColumnTxtStrong">2017 - 2020</p>
								<p class="ColumnTxtLight">Web Bachelor’s degree / Hétic</p>
							</div>
							<div class="ColumnInfos MarginBottom">
								<p class="ColumnTxtStrong">2014 - 2017</p>
								<p class="ColumnTxtLight">Bac Graphic Production / Gobelins</p>
							</div>
							<div class="ColumnInfos">
								<p class="ColumnTxtStrong">1998 - 2014</p>
								<p class="ColumnTxtLight">Pro Rock–Paper–Scissors Player</p>
							</div>
						</div>
					</div>
					<div data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="300" class="ColumnTitle Experiences">
						<p>Experiences</p>
						<div class="FooterMobileWrapper">
							<div class="ColumnInfos MarginBottom">
								<p class="ColumnTxtStrong">2019 - 2020</p>
								<p class="ColumnTxtLight">UI Designer / LaFusée</p>
							</div>
							<div class="ColumnInfos MarginBottom">
								<p class="ColumnTxtStrong">2018 - 2019</p>
								<p class="ColumnTxtLight">UI Designer / BlackPizza</p>
							</div>
							<div class="ColumnInfos">
								<p class="ColumnTxtStrong">2014 - 2017</p>
								<p class="ColumnTxtLight">Graphic Designer / GodSaveTheQueen</p>
							</div>
						</div>
					</div>
				</div>
				<div id="Contact" data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="500" class="ColumnTitle Contact">
					<p>Contact</p>
					<div class="ColumnInfos">
						<div class="SocialLinks">
							<a href="https://www.linkedin.com/in/mathieu-b-61034493/" target="_blank">Linkedin</a>
							<a href="mailto:matblok@orange.fr">@Mail</a>
							<a href="assets/mathieublokcv.pdf" download>CV</a>
						</div>
					</div>
				</div>
			</div>
			<div data-aos="fade-down" data-aos-duration="250" data-aos-easing="ease-in" data-aos-delay="100" class="CircleRotate">
				<img src="assets/img//pastille.svg" alt="Pastille">
			</div>
		</footer>
	</div>
	<div id="awwwards" style="position: fixed; z-index: 999; transform: translateY(-50%); top: 50%;  right: 0"><a href="https://www.awwwards.com/sites/blok-book" target="_blank"><svg width="53.08" height="171.358"><path class="js-color-bg" fill="black" d="M0 0h53.08v171.358H0z"></path><g class="js-color-text" fill="white"><path d="M20.047 153.665v-2.134l6.387-2.411-6.387-2.413v-2.133h10.23v1.9h-6.314l5.379 1.959v1.374l-5.379 1.958h6.314v1.9zM29.898 141.038a3.319 3.319 0 0 1-1.361 1.294c-.573.297-1.221.445-1.943.445-.721 0-1.368-.148-1.943-.445a3.326 3.326 0 0 1-1.359-1.294c-.331-.565-.497-1.232-.497-2.002 0-.771.166-1.438.497-2.003a3.317 3.317 0 0 1 1.359-1.293c.575-.298 1.223-.446 1.943-.446.723 0 1.37.148 1.943.446a3.31 3.31 0 0 1 1.361 1.293c.33.564.496 1.232.496 2.003.001.77-.165 1.437-.496 2.002m-1.703-3.348c-.435-.33-.968-.496-1.602-.496-.633 0-1.167.166-1.6.496-.435.331-.651.779-.651 1.346 0 .564.217 1.013.651 1.344.433.332.967.498 1.6.498.634 0 1.167-.166 1.602-.498.434-.331.649-.779.649-1.344.001-.566-.215-1.015-.649-1.346M30.117 131.176c-.186.326-.386.548-.6.665h.76v1.812H19.93v-1.812h3.654c-.215-.166-.4-.414-.556-.746a2.422 2.422 0 0 1-.235-1.038c0-1.082.345-1.912 1.031-2.492.688-.579 1.611-.869 2.771-.869s2.083.29 2.771.869c.687.58 1.029 1.41 1.029 2.492 0 .419-.093.792-.278 1.119m-1.871-2.099c-.399-.32-.949-.481-1.651-.481-.711 0-1.265.161-1.659.481-.395.322-.592.731-.592 1.229s.197.904.592 1.22c.395.317.948.476 1.659.476.712 0 1.264-.158 1.659-.476.394-.315.592-.723.592-1.22s-.2-.907-.6-1.229M21.625 124.98c-.225.225-.502.337-.833.337s-.608-.112-.833-.337-.337-.502-.337-.833c0-.332.112-.608.337-.833s.502-.337.833-.337.608.112.833.337.336.501.336.833c0 .332-.111.609-.336.833m1.286-1.739h7.367v1.812h-7.367v-1.812zM19.93 119.389h10.349v1.813H19.93zM29.832 116.189c-.375.531-.853.921-1.433 1.169a4.548 4.548 0 0 1-3.611 0 3.339 3.339 0 0 1-1.433-1.169c-.375-.532-.563-1.196-.563-1.995 0-.77.184-1.413.55-1.93a3.282 3.282 0 0 1 1.381-1.14 4.23 4.23 0 0 1 1.71-.365h.746v5.072a1.798 1.798 0 0 0 1.169-.49c.332-.307.497-.724.497-1.249 0-.41-.094-.753-.278-1.031-.185-.277-.473-.529-.862-.753l.541-1.462c.691.302 1.224.724 1.592 1.265.371.541.557 1.234.557 2.083 0 .799-.188 1.463-.563 1.995m-4.086-3.574c-.408.089-.746.262-1.008.52-.263.258-.395.611-.395 1.06 0 .429.136.784.408 1.067.273.282.604.458.994.526v-3.173zM20.047 102.852v-1.899l10.231-3.464v2.046l-2.412.746v3.244l2.412.745v2.046l-10.231-3.464zm6.065-2.031l-3.552 1.08 3.552 1.082v-2.162zM22.91 97.414v-1.827l5.059-1.316-5.059-1.243v-1.695l5.059-1.242-5.059-1.316v-1.827l7.367 2.354v1.607l-4.763 1.273 4.763 1.27v1.609zM29.811 85.676c-.391.419-.94.628-1.652.628-.73 0-1.314-.277-1.754-.833-.438-.555-.658-1.306-.658-2.251v-1.286h-.32c-.36 0-.632.122-.812.366-.181.243-.271.55-.271.92 0 .633.282 1.058.848 1.272l-.352 1.534a2.316 2.316 0 0 1-1.482-.942c-.375-.513-.563-1.132-.563-1.864 0-.984.261-1.747.782-2.287.521-.541 1.289-.812 2.302-.812h4.4v1.491l-.937.19c.702.575 1.053 1.33 1.053 2.265 0 .654-.195 1.19-.584 1.609m-1.383-3.245c-.276-.331-.645-.497-1.104-.497h-.144v1.213c0 .4.078.709.233.93.156.219.394.327.716.327a.658.658 0 0 0 .52-.226c.132-.151.197-.349.197-.593 0-.439-.14-.822-.418-1.154M22.91 78.179v-1.813h1.199a2.93 2.93 0 0 1-.972-.965 2.324 2.324 0 0 1-.345-1.213c0-.273.05-.57.146-.892l1.682.336a1.452 1.452 0 0 0-.205.76c0 .576.262 1.048.783 1.418s1.342.556 2.461.556h2.617v1.813H22.91zM29.364 71.716c-.687.561-1.61.84-2.771.84-1.158 0-2.082-.279-2.77-.84s-1.029-1.352-1.029-2.375c0-.42.074-.802.226-1.147.151-.347.339-.607.563-.782H19.93v-1.813h10.348v1.813h-.76c.224.117.427.35.607.693.18.348.27.759.27 1.236 0 1.023-.344 1.814-1.031 2.375m-1.11-3.99c-.396-.316-.947-.476-1.66-.476-.711 0-1.264.159-1.657.476a1.493 1.493 0 0 0-.593 1.221c0 .496.197.906.593 1.229.394.32.946.481 1.657.481.703 0 1.252-.161 1.652-.481.4-.322.6-.732.6-1.229 0-.498-.198-.905-.592-1.221M35.48 17.006l-4.783 14.969h-3.265l-2.584-9.682-2.584 9.682h-3.267l-4.782-14.969h3.712L20.6 27.282l2.525-10.276h3.445l2.525 10.276 2.673-10.276zM37.978 27.163c1.425 0 2.495 1.068 2.495 2.495 0 1.425-1.07 2.495-2.495 2.495-1.426 0-2.495-1.07-2.495-2.495-.001-1.427 1.069-2.495 2.495-2.495"></path></g></svg></a></div>
</body>
</html>
