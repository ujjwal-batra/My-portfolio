<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Mathieu Blok, French UX UI Designer & Front-Developer">
<meta name="keywords" content="Portfolio,Webdesign,Graphiste,DA,Developer,Paris,France,HTML,CSS,JS,Mathieu,Mathieu Blok,Blok,Hétic">
<meta name="Mathieu Blok" content="Matt Blok Book">
<link href="css/style.css" rel="stylesheet">
<link href="css/reset.css" rel="stylesheet">
<link rel="icon" href="assets/img/favicon.ico" />
<!-- Library CSS -->
<link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
<!-- Library CSS -->
<title>Blok Book</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function() {
$('.js-scrollTo').on('click', function() { // Au clic sur un élément
var page = $(this).attr('href'); // Page cible
var speed = 750; // Durée de l'animation (en ms)
$('html, body').animate( { scrollTop: $(page).offset().top }, speed ); // Go
return false;
});
});
</script>
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script src="js/script.js" async></script>
<script>
$(window).scroll(function() {
var scroll = $(window).scrollTop();

if (scroll >= 120) {
$("nav").addClass("NavFixedBackground");
} else {
$("nav").removeClass("NavFixedBackground");
}
});
</script>
</head>



<body id="Top" class="Wrapper fadeIn animated ProjectBody">
	<header>
		<nav>
	<div class="NavFixedWrapper">
		<div class="HeaderNavLeft">
			<a href="index.php" class="Name">Matt Blok <span>👨🏼‍💼</span></a>
		</div>
		<div class="HeaderNavRight">
			<ul>
				<li><a href=index.php#Projects>Work</a></li>
				<li><a href=index.php#About>About</a></li>
				<li><a href=index.php#Contact>Contact</a></li>
			</ul>
		</div>
	</div>
</nav>	</header>

	<section class="ProjectHeader">
		<div class="ProjectHeaderWrapper">
			<h1 class="ProjectNameTemplate BlackColor">Géodia Conseils</h1>
			<p class="ProjectDescriptionTemplate">Creation of a multi-page template intended for surveyors. Homepage, article page, activity page and offices page with also a route to request a quote.</p>
			<div class="ProjectTemplateTagsWrapper">
				<p class="ProjectTemplateTag">UI Design</p>
				<p class="ProjectTemplateTag">Nov 2019</p>
			</div>
		</div>
	</section>
	<section class="ProjectContent">
		<div class="ProjectContentWrapper">
			<img class="ProjectContentImg" src="assets/img/projects/geodia/home.png" alt="Image Projet">
			<div class="ProjectContentTxtWrapper">
				<p data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="70"class="ProjectContentTxtTitle">The project</p>
				<p data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="70"class="ProjectContentTxtP">The land surveyor is a person exercising a profession which basically consists in <span class="StrongProjectTxt">establishing various measures</span> affecting land properties.</p>
				<div class="JoeDescriptionProject" data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="70">
			</div>
			</div>

			<img class="ProjectContentImg" data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="100" src="assets/img/projects/geodia/multipages-a.png" alt="Image Projet">
			<img class="ProjectContentImg MarginTop40px" data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="100" src="assets/img/projects/geodia/multipages-b.png" alt="Image Projet">
			<div class="ProjectContentTxtWrapper">
				<p data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="70"class="ProjectContentTxtTitle">The land surveyor</p>
				<p data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="70"class="ProjectContentTxtP">He studies, projects and directs the development or land, rural or urban improvement of a public or private property.</p>
			</div>
			<img class="ProjectContentImg IphoneImgMobile" src="assets/img/projects/geodia/mobile.png" alt="Image Projet" data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="100">
			<div class="ProjectContentTxtWrapper">
				<p data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="70"class="ProjectContentTxtTitle">Production</p>
				<p data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="70"class="ProjectContentTxtP">Project carried out in collaboration with La Fusée agency as part of my work-study program at Hétic in the 3rd year of the Web Bachelor’s degree.</p>
			</div>
		</div>
	</section>
	<section class="NextProject">
		<div data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="70">
			<a class="CTA CTANextProject" href="project-xaalys.php">Next project
				<img class="ArrowCta" src="assets/img/aboutus/arrow.svg" alt="Next">
			</a>
		</div>
	</section>
	<div data-aos="fade-down" data-aos-duration="250" data-aos-easing="ease-in" data-aos-delay="100" class="CircleRotate">
		<img src="assets/img//pastille.svg" alt="Pastille">
	</div>
</body>
</html>
