<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Mathieu Blok, French UX UI Designer & Front-Developer">
<meta name="keywords" content="Portfolio,Webdesign,Graphiste,DA,Developer,Paris,France,HTML,CSS,JS,Mathieu,Mathieu Blok,Blok,Hétic">
<meta name="Mathieu Blok" content="Matt Blok Book">
<link href="css/style.css" rel="stylesheet">
<link href="css/reset.css" rel="stylesheet">
<link rel="icon" href="assets/img/favicon.ico" />
<!-- Library CSS -->
<link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
<!-- Library CSS -->
<title>Blok Book</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function() {
$('.js-scrollTo').on('click', function() { // Au clic sur un élément
var page = $(this).attr('href'); // Page cible
var speed = 750; // Durée de l'animation (en ms)
$('html, body').animate( { scrollTop: $(page).offset().top }, speed ); // Go
return false;
});
});
</script>
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script src="js/script.js" async></script>
<script>
$(window).scroll(function() {
var scroll = $(window).scrollTop();

if (scroll >= 120) {
$("nav").addClass("NavFixedBackground");
} else {
$("nav").removeClass("NavFixedBackground");
}
});
</script>
</head>



<body id="Top" class="Wrapper fadeIn animated ProjectBody">
	<header>
		<nav>
	<div class="NavFixedWrapper">
		<div class="HeaderNavLeft">
			<a href="index.php" class="Name">Matt Blok <span>👨🏼‍💼</span></a>
		</div>
		<div class="HeaderNavRight">
			<ul>
				<li><a href=index.php#Projects>Work</a></li>
				<li><a href=index.php#About>About</a></li>
				<li><a href=index.php#Contact>Contact</a></li>
			</ul>
		</div>
	</div>
</nav>	</header>

	<section class="ProjectHeader">
		<div class="ProjectHeaderWrapper">
			<h1 class="ProjectNameTemplate BlackColor">Sodexo Ventures</h1>
			<p class="ProjectDescriptionTemplate">Sodexo allows you to combine agility and creativity of young companies, with the investment capacity and expertise of Sodexo Group.</p>
			<div class="ProjectTemplateTagsWrapper">
				<p class="ProjectTemplateTag">UI Design</p>
				<p class="ProjectTemplateTag">Jan 2020</p>
			</div>
		</div>
	</section>
	<section class="ProjectContent">
		<div class="ProjectContentWrapper">
			<img class="ProjectContentImg IphoneImgMobile" src="assets/img/projects/sodexo/mobile-a.png" alt="Image Projet">
			<div class="ProjectContentTxtWrapper">
				<p data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="70"class="ProjectContentTxtTitle">Mobile Only</p>
				<p data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="70"class="ProjectContentTxtP">An analysis of the master pages and the workflow to product <span class="StrongProjectTxt">all the
				mobile versions</span> of the UI redesign of the Sodexo Ventures website.</p>
				<div data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="70">
					<a class="CTA" href="https://sodexo-ventures.com/" target="_blank">Website<img class="ArrowCta" src="assets/img/aboutus/arrow.svg"></a>
				</div>
			</div>
			<img class="ProjectContentImg IphoneImgMobile" data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="100" src="assets/img/projects/sodexo/mobile-b.png" alt="Image Projet">
			<img class="ProjectContentImg MarginTop IphoneImgMobile" data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="100" src="assets/img/projects/sodexo/mobile-c.png" alt="Image Projet">
			<img class="ProjectContentImg MarginTop IphoneImgMobile" data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="100" src="assets/img/projects/sodexo/mobile-d.png" alt="Image Projet">
			<div class="ProjectContentTxtWrapper">
				<p data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="70"class="ProjectContentTxtTitle">Production</p>
				<p data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="70"class="ProjectContentTxtP">Project carried out in collaboration with Black Pizza agency as part of my work-study program at Hétic in the 2nd year of the Web Bachelor’s degree.</p>
			</div>
		</div>
	</section>
	<section class="NextProject">
		<div data-aos="fade-up" data-aos-duration="800" data-aos-easing="ease-out" data-aos-delay="70">
			<a class="CTA CTANextProject" href="project-photographer.php">Next project
				<img class="ArrowCta" src="assets/img/aboutus/arrow.svg" alt="Next">
			</a>
		</div>
	</section>
	<div data-aos="fade-down" data-aos-duration="250" data-aos-easing="ease-in" data-aos-delay="100" class="CircleRotate">
		<img src="assets/img//pastille.svg" alt="Pastille">
	</div>
</body>
</html>
